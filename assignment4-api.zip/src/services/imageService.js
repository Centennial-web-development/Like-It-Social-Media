const Image = require('../models/imageModel');

async function postImage(file) {
    const image = new Image({
        name: file.originalname,
        data: file.buffer
    });

    return image.save();
}

async function deleteImage(imageId) {
    return Image.findByIdAndDelete(imageId);
}

const imageService = {
    postImage,
    deleteImage
};

module.exports = imageService

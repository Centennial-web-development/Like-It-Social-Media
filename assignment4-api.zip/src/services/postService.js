const Like = require("../models/likeModel");
const Comment = require("../models/commentModel ");
const Post = require("../models/postModel");
const User = require("../models/userModel");

// Create a new post
async function createPost(postData, userId) {
  const { content, imageId } = postData;
  const user = await User.findById(userId);
  if (!user) {
    throw new Error("User not found");
  }

  const post = new Post({ content, image:imageId, user: userId });
  await post.save();

  user.posts.push(post);
  await user.save();

  return post;
}

// Get all posts
async function getAllPosts() {
  const posts = await Post.find()
    .sort({ datePosted: -1 })
    .populate("user", "username")
    .populate("image", "data")
    .populate({
      path: "comments",
      populate: { path: "user", select: "username" },
    })
    .populate({
      path: "likes",
      populate: { path: "user", select: "username" },
    })
    .lean();

  return posts;
}
// get post by id
async function getPostById(postId) {
  const post = await Post.findById(postId)
    .populate("user", "username")
    .populate("image", "data")
    .populate({
      path: "comments",
      populate: { path: "user", select: "username" },
    })
    .populate({
      path: "likes",
      populate: { path: "user", select: "username" },
    })
    .lean();

  if (!post) {
    throw new Error("Post not found");
  }

  return post;
}

// Update a post
async function updatePost(postId, userId, postData) {
  const { content, image } = postData;

  const post = await Post.findById(postId);
  if (!post) {
    throw new Error("Post not found");
  }

  // Check if the user owns the post
  if (post.user.toString() !== userId) {
    throw new Error("You are not authorized to update this post");
  }

  post.content = content || post.content;
  post.image = image || post.image;
  await post.save();

  return post;
}

// Delete a post
async function deletePost(postId, userId) {
  const post = await Post.findById(postId);
  if (!post) {
    throw new Error("Post not found");
  }

  // Check if the user owns the post
  if (post.user.toString() !== userId) {
    throw new Error("You are not authorized to delete this post");
  }

  await Post.deleteOne({ _id: postId, user: userId });

  // Remove the post from user's posts array
  const user = await User.findById(userId);
  if (!user) {
    throw new Error("User not found");
  }

  const index = user.posts.indexOf(postId);
  if (index !== -1) {
    user.posts.splice(index, 1);
    await user.save();
  }
}

// Like  or unlike a post
async function likePost(postId, userId) {

  const post = await Post.findById(postId);
  if (!post) {
    throw new Error("Post not found");
  }

  const user = await User.findById(userId);
  if (!user) {
    throw new Error("User not found");
  }

  // check user already liked
  const exists = await Like.findOne({ user: userId, post: postId });
  if (exists) {
    // unlike
    const index = post.likes.indexOf(exists._id);
    if (index !== -1) {
      post.likes.splice(index, 1);

      user.likes.splice(index, 1);
      await user.save();

      if (post.likesCount > 0) post.likesCount--;

      await post.save();
      await Like.deleteOne({ user: userId, post: postId });

      return 0;
    }
  } else {
    // like
    const like = new Like({ user: userId, post: postId });
    await like.save();

    post.likes.push(like);
    
    post.likesCount++;
    await post.save();

    user.likes.push(like);
    await user.save();

    return 1;
  }
}

// Comment on a post
async function commentOnPost(postId, userId, content) {
  const post = await Post.findById(postId);
  if (!post) {
    throw new Error("Post not found");
  }

  const comment = new Comment({ content, user: userId, post: postId });
  await comment.save();

  post.comments.push(comment);
  post.commentsCount++;
  await post.save();

  return comment;
}

// Uncomment on a post
async function uncommentOnPost(postId, userId, commentId) {
  const post = await Post.findById(postId);
  if (!post) {
    throw new Error("Post not found");
  }

  const comment = await Comment.findOne({
    _id: commentId,
    post: postId,
    user: userId,
  });

  if (!comment) {
    throw new Error("Comment not found");
  }

  const index = post.comments.indexOf(comment._id);
  if (index !== -1) post.comments.splice(index, 1);

  if (post.commentsCount > 0) post.commentsCount--;
  await post.save();
}

const postService = {
  createPost,
  getAllPosts,
  getPostById,
  updatePost,
  deletePost,
  likePost,
  commentOnPost,
  uncommentOnPost,
};

module.exports = postService;

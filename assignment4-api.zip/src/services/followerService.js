const User = require("../models/userModel");
const Follower = require("../models/followerModel");

// suggest who to follow given a particular user id
async function whoToFollow(userId) {
  let users;
  let followingMe = [];

  if (userId !== 0) {
    followingMe = await Follower.find({ following: userId }).distinct(
      "follower"
    );
    users = await User.find({ _id: { $ne: userId, $nin: followingMe } });
  } else {
    users = await User.find();
  }

  return users.map((user) => ({
    user: user,
    following_you: followingMe.includes(user._id),
    following: getUserFollowing(user._id)
  }));
}

// check if user is following another user
async function isFollowing(followerId, followingId) {
  const following = await Follower.findOne({
    follower: followerId,
    following: followingId,
  });
  return !!following;
}

// follow
async function follow(followerId, followingId) {
  const follow = await Follower.create({
    follower: followerId,
    following: followingId,
  });
  return follow;
}

// unfollow
async function unfollow(followerId, followingId) {
  const unfollow = await Follower.deleteOne({
    follower: followerId,
    following: followingId,
  });
  return unfollow;
}

// get users following the given username
async function getUserFollowers(username) {
  const user = await User.findOne({ username: username });
  const followers = await Follower.find({ following: user._id }).sort({
    from_date: -1,
  });

  return followers.map(async (follower) => ({
    follower: follower,
    user: await User.findById(follower.follower),
    following: (await isFollowing(user._id, follower.follower)) ? 1 : 0,
  }));
}

// get users who the user with given username follows
async function getUserFollowing(userId) {
  const user = await User.findOne({ _id: userId });
  const following = await Follower.find({ follower: user._id }).sort({
    from_date: -1,
  });

  return following.map(async (follow) => ({
    following: follow,
    user: await User.findById(follow.following),
    following_you: (await isFollowing(follow.follower, user._id)) ? 1 : 0,
  }));
}

module.exports = {
  whoToFollow,
  isFollowing,
  follow,
  unfollow,
  getUserFollowers,
  getUserFollowing,
};

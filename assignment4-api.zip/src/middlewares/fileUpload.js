const multer = require('multer');

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

function fileUpload(options) {
    let multerUpload;
    if (options.single) {
        multerUpload = upload.single(options.single);
    } else if (options.multiple) {
        multerUpload = upload.fields(options.multiple);
    }

    return multerUpload;
}

module.exports = fileUpload;

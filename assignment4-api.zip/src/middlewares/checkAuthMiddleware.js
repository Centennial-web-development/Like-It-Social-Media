const jwt = require("jsonwebtoken");
const User = require("../models/userModel");

function checkAuth(isRequired = true) {
  return async (req, res, next) => {
    const authorizationHeader = req.headers["authorization"];
    const token = authorizationHeader ? authorizationHeader.replace("Bearer ", "") : null;

    try {
      if (!token) {
        if (isRequired) {
          return res.status(401).json({ message: "Missing bearer token" });
        }
        return next();
      }

      // Decode jwt token
      const decodedToken = jwt.verify(token, process.env.JWT_SECRET);
      const userId = decodedToken.user.id;

      // Check if user exists
      const user = await User.findById(userId);
      if (!user) {
        if (isRequired) {
          return res.status(401).json({ message: "User not found" });
        }
        return next();
      }

      req.user = user;
      next();
    } catch (err) {
      console.log(err);
      if (isRequired) {
        return res.status(401).json({ message: "Invalid token" });
      }
      return next();
    }
  };
}

module.exports = checkAuth;

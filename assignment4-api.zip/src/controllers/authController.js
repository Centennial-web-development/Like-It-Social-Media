const authService = require("../services/authService");

async function login(req, res) {
  try {
    const { username, password } = req.body;
    const { token, user } = await authService.login(username, password);
  
    res.json({
      token,
      user: {
        username: user.username,
        first_name: user.first_name,
        last_name: user.last_name,
        bio: user.bio,
      },
    });
  } catch (err) {
    res.status(500).json({
      message: err.message,
    });
  }
}

// register
async function register(req, res) {
  try {
    await authService.register(req.body);
    res.json({ message: "Account created successfully" });
  } catch (err) {
    res.status(500).json({
      message: err.message,
    });
  }
}

module.exports = {
  login,
  register,
};

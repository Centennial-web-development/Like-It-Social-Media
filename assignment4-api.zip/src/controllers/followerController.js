const followerService = require('../services/followerService');

async function suggestFollow(req, res) {
    const userId = req.user ? req.user?.id : 0;
    try {
        const suggestions = await followerService.whoToFollow(userId);
        res.json(suggestions);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Internal server error' });
    }
}

async function followUser(req, res) {
    const { followerId, followingId } = req.body;
    try {
        const follow = await followerService.follow(followerId, followingId);
        res.json(follow);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Internal server error' });
    }
}

async function unfollowUser(req, res) {
    const { followerId, followingId } = req.body;
    try {
        const unfollow = await followerService.unfollow(followerId, followingId);
        res.json(unfollow);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Internal server error' });
    }
}

module.exports = {
    suggestFollow,
    followUser,
    unfollowUser
};

const User = require("../models/userModel");

// get all users
async function getAllUsers(req, res) {
  try {
    const users = await User.find()
      .populate({
        path: "posts",
        populate: { path: "user", select: "username" },
      })
      .populate({
        path: "likes",
        populate: { path: "post" },
      });
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}
// get user by id
async function getProfile(req, res) {
  try {
    const user = await User.findById(req.user.id)
      .populate({
        path: "posts",
        populate: { path: "user", select: "username" },
      })
      .populate({
        path: "likes",
        populate: { path: "post" },
      });
    res.json(user);
  } catch (err) {
    res.status(404).json({ message: err.message });
  }
}

async function updateProfile(req, res) {
  try {
    const user = await User.findByIdAndUpdate(
      req.user.id,
      {
        $set: {
          bio: req.body.bio,
          first_name: req.body.first_name,
          last_name: req.body.last_name,
        },
      },
      { new: true }
    );

    res.json(user);
  } catch (err) {
    res.status(404).json({ message: err.message });
  }
}

// get user by id
async function getUserById(req, res) {
  try {
    console.log("getting user");

    const user = await getUserByIdOrUsername(req.params.id);

    res.json(user);
  } catch (err) {
    console.log(err);
    res.status(404).json({ message: err.message });
  }
}

async function getUserByIdOrUsername(idOrUsername) {
  let user;
  if (idOrUsername.match(/^[0-9a-fA-F]{24}$/)) {
    // If is
    user = await User.findById(idOrUsername)
      .populate({
        path: "posts",
        populate: { path: "user", select: "username" },
      })
      .populate({
        path: "likes",
        populate: { path: "post" },
      });
  } else {
    // by username
    user = await User.findOne({ username: idOrUsername })
      .populate({
        path: "posts",
        populate: { path: "user", select: "username" },
      })
      .populate({
        path: "likes",
        populate: { path: "post" },
      });
  }
  return user;
}

// create user
async function createUser(req, res) {
  const hashedPassword = await User.hashPassword(password);

  const user = new User({
    username: req.body.username,
    password: hashedPassword,
    first_name: req.body.first_name,
    last_name: req.body.last_name,
  });

  try {
    const exists = await User.exists({ username: req.body.username });

    if (exists) {
      return res.status(400).json({ message: "Username already exist" });
    }

    const newUser = await user.save();
    res.status(201).json(newUser);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
}

// update user
async function updateUser(req, res) {
  try {
    const user = await User.findById(req.params.id);
    if (user == null) {
      return res.status(404).json({ message: "User not found" });
    }

    if (req.body.first_name != null) {
      user.first_name = req.body.first_name;
    }
    if (req.body.last_name != null) {
      user.last_name = req.body.last_name;
    }
    if (req.body.bio != null) {
      user.bio = req.body.bio;
    }

    const updatedUser = await user.save();
    res.json(updatedUser);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
}

// delete user
async function deleteUser(req, res) {
  try {
    await res.user.remove();
    res.json({ message: "Deleted User" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

module.exports = {
  getAllUsers,
  getUserById,
  getProfile,
  updateProfile,
  createUser,
  updateUser,
  deleteUser,
};

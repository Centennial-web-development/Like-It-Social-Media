const imageService = require("../services/imageService");
const postService = require("../services/postService");

// Create a new post
async function createPost(req, res) {
  const userId = req.user.id;
  try {

    console.log("files", req.file, req.files)
    if (req.file) {
      const image = await imageService.postImage(req.file);
      console.log(req.file)
      req.body.imageId = image._id;
    }

    const post = await postService.createPost(req.body, userId);

    res.json({ post, message: "Post created successfully" });
  } catch (err) {
    res.status(500).json({
      message: err.message,
    });
  }
}

// Get all posts
async function getPosts(req, res) {
  try {
    const posts = await postService.getAllPosts();
    res.json({ posts });
  } catch (err) {
    res.status(500).json({
      message: err.message,
    });
  }
}
async function getPostById(req, res) {
  const postId = req.params.id;

  try {
    const post = await postService.getPostById(postId);
    res.json({ post });
  } catch (err) {
    res.status(500).json({
      message: err.message,
    });
  }
}

// Update a post
async function updatePost(req, res) {
  const postId = req.params.id;
  const userId = req.user.id;

  try {
    const post = await postService.updatePost(postId, userId, req.body);
    res.json({ post, message: "post updated" });
  } catch (err) {
    res.status(500).json({
      message: err.message,
    });
  }
}

// Delete a post
async function deletePost(req, res) {
  const postId = req.params.id;
  const userId = req.user.id;

  try {
    await postService.deletePost(postId, userId);
    res.json({ message: "Post deleted" });
  } catch (err) {
    res.status(500).json({
      message: err.message,
    });
  }
}

// Like a post
async function likePost(req, res) {
  const postId = req.params.id;
  const userId = req.user.id;

  try {
    await postService.likePost(postId, userId);
    res.json({ message: "ok" });
  } catch (err) {
    res.status(500).json({
      message: err.message,
    });
  }
}
// Comment on a post
async function commentOnPost(req, res) {
  const postId = req.params.id;
  const userId = req.user.id;

  try {
    await postService.commentOnPost(postId, userId, req.body.content);
    res.json({ message: "commented successfully" });
  } catch (err) {
    res.status(500).json({
      message: err.message,
    });
  }
}

// Uncomment on a post
async function uncommentOnPost(req, res) {
  const postId = req.params.id;
  const commentId = req.params.commentId;
  const userId = req.user.id;

  try {
    await postService.uncommentOnPost(postId, userId, commentId);
    res.json({ message: "deleted" });
  } catch (err) {
    res.status(500).json({
      message: err.message,
    });
  }
}

module.exports = {
  createPost,
  getPosts,
  getPostById,
  updatePost,
  deletePost,
  likePost,
  commentOnPost,
  uncommentOnPost,
};

const mongoose = require("mongoose");
const { Schema, model } = mongoose;

const postSchema = new Schema({
  content: { type: String, required: true },
  image: { type: Schema.Types.ObjectId, ref: "Image" },
  datePosted: { type: Date, default: Date.now },
  likesCount: { type: Number, default: 0 },
  commentsCount: { type: Number, default: 0 },
  user: { type: Schema.Types.ObjectId, ref: "User" },
  comments: [{ type: Schema.Types.ObjectId, ref: "Comment" }],
  likes: [{ type: Schema.Types.ObjectId, ref: "Like" }],
});

const Post = model("Post", postSchema);

module.exports = Post;

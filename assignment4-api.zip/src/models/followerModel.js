const mongoose = require('mongoose');

const followerSchema = new mongoose.Schema({
    follower: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    following: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    from_date: {
        type: Date,
        default: Date.now
    }
});

const Followers = mongoose.model('Follower', followerSchema);

module.exports = Followers;

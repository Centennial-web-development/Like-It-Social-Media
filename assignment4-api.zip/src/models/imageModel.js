const mongoose = require("mongoose");
const { Schema, model } = mongoose;

const imageSchema = new Schema({
    name: String,
    data: Buffer
});

const Image = model('Image', imageSchema);
module.exports = Image;

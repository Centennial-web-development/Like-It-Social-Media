const express = require("express");
const userRoutes = express.Router();
const userController = require("../controllers/userController");
const checkAuth = require("../middlewares/checkAuthMiddleware");

userRoutes.get("/", checkAuth(), userController.getAllUsers);
userRoutes.get("/profile", checkAuth(), userController.getProfile);
userRoutes.post("/profile", checkAuth(), userController.updateProfile);
userRoutes.patch("/:id", checkAuth(), userController.updateUser);
userRoutes.delete("/:id", checkAuth(), userController.deleteUser);
userRoutes.get("/:id", checkAuth(false), userController.getUserById);

module.exports = userRoutes;
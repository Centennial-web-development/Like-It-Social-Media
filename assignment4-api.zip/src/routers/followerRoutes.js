const express = require('express');
const followerRoutes = express.Router();
const followerController = require('../controllers/followerController');
const checkAuth = require('../middlewares/checkAuthMiddleware');


followerRoutes.get('/suggest',  checkAuth(false), followerController.suggestFollow);
followerRoutes.post('/follow', checkAuth(), followerController.followUser);
followerRoutes.post('/unfollow',checkAuth(), followerController.unfollowUser);

module.exports = followerRoutes;

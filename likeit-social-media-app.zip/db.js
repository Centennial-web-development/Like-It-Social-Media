const mongoose = require("mongoose");

async function connectDb() {
  console.log("Connecting to MongoDB");
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("Connected to MongoDB");
  } catch (err) {
    console.error("MongoDB connection error:", err);
  }

  mongoose.connection.on("error", (err) => {
    console.error("MongoDB connection error:", err);
  });

  mongoose.connection.on("connected", () => {
    console.log("Connected to MongoDB");
  });
}

module.exports = connectDb;

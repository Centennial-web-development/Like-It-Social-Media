const mongoose = require("mongoose");
const { Schema, model } = mongoose;

const likeSchema = new Schema({
  dateLiked: { type: Date, default: Date.now },
  user: { type: Schema.Types.ObjectId, ref: 'User' },
  post: { type: Schema.Types.ObjectId, ref: 'Post' }
});

const Like = model("Like", likeSchema);

module.exports = Like;

const jwt = require("jsonwebtoken");
const User = require("../models/userModel");

//login
async function login(username, password) {
  if (!username || !password) {
    throw new Error("Please provide username and password");
  }
  const user = await User.verifyCredentials(username, password);
  if (!user) {
    throw new Error("Invalid credentials");
  }

  const payload = {
    user: {
      id: user.id,
    },
  };

  const token = jwt.sign(
    payload,
    process.env.JWT_SECRET,
    { expiresIn: "1h" },
    (err, token) => {
      if (err) {
        throw new Error("Failed to generate token");
      } else {
        return token
      }
    }
  );

  return {user, token};
}

// register
async function register(registerData) {
  const { username, password, first_name, last_name } = registerData;

  if (!username || !password || !first_name || !last_name) {
    throw new Error("Please provide first_name, last_name, username, password");
  }

  const hashedPassword = await User.hashPassword(password);

  const user = new User({
    username: username,
    password: hashedPassword,
    first_name: first_name,
    last_name: last_name,
  });

  const exists = await User.exists({ username });

  if (exists) {
    throw new Error("Username already exist");
  }

  const newUser = await user.save();
  return newUser;
}

const authService = {
  login,
  register,
};

module.exports = authService;

const jwt = require("jsonwebtoken");
const User = require("../models/userModel");

async function checkAuth(req, res, next) {
  const _user = req.session.user
  if (!_user) {
    return res.redirect("/auth/login");
  }

  try {
    const user = await User.findById(_user.id);
    if (!user) {
     return res.redirect("/auth/login");
    }
    req.user = _user;
    next();
  } catch (err) {
    console.log(err);
    return res.redirect("/auth/login");
  }
}

module.exports = checkAuth;

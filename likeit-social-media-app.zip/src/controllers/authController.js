const authService = require("../services/authService");

//show login
async function showLogin(req, res) {
  res.render("login");
}

async function login(req, res) {
  try {
    const { username, password } = req.body;
    const { token, user } = await authService.login(username, password);
    req.session.token = token;
    req.session.isLoggedIn = true;

    req.session.user = {
      id: user._id,
      first_name: user.first_name,
      last_name: user.last_name,
      username: user.username,
      full_name: user.first_name + " " + user.last_name,
    };
    res.redirect("/");
  } catch (err) {
    res.render("login", { error: err.message, data: req.body });
  }
}

//show register
async function showRegister(req, res) {
  res.render("register");
}

// register
async function register(req, res) {
  try {
    await authService.register(req.body);
    res.render("register", { message: "Account created successfully" });
  } catch (err) {
    res.render("register", {
      data: req.body,
      error: err.message,
    });
  }
}

// register
async function logout(req, res) {
  req.session.destroy((err) => res.redirect("/auth/login"));
}

module.exports = {
  login,
  showLogin,
  showRegister,
  register,
  logout
};

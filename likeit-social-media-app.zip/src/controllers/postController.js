const postService = require("../services/postService");

// Create a new post
async function createPost(req, res) {
  const userId = req.user.id;
  try {
    await postService.createPost(req.body, userId);

    res.redirect("/posts");
  } catch (err) {
    res.render("posts", { error: err.message });
  }
}

// Get all posts
async function getPosts(req, res) {
  try {
    const posts = await postService.getAllPosts();

    res.render("posts", { posts });
  } catch (err) {
    res.render("posts", { error: err.message });
  }
}

async function getPostById(req, res) {
  const postId = req.params.id;

  try {
    const post = await postService.getPostById(postId);
    res.render("post", { post });
  } catch (err) {
    res.render("posts", { error: err.message });
  }
}

// Update a post
async function updatePost(req, res) {
  const postId = req.params.id;
  const userId = req.user.id;

  try {
    const post = await postService.updatePost(postId, userId, req.body);
  } catch (err) {
    res.render("editPost", { error: err.message });
  }
}

// Delete a post
async function deletePost(req, res) {
  const postId = req.params.id;
  const userId = req.user.id;

  try {
    await postService.deletePost(postId, userId);
    res.redirect("/posts")
  } catch (err) {
    res.render("posts", { error: err.message });
  }
}

// Like a post
async function likePost(req, res) {
  const postId = req.params.id;
  const userId = req.user.id;

  try {
    
    await postService.likePost(postId, userId)
    res.redirect("/posts");
    
  } catch (err) {
    res.render("posts", { error: err.message });
  }
}

// Comment on a post
async function commentOnPost(req, res) {
  const postId = req.params.id;
  const userId = req.user.id;

  try {
    await postService.commentOnPost(postId, userId, req.body.content);
    res.redirect(`/posts/${postId}`);
  } catch (err) {
    res.render("posts", { error: err.message });
  }
}

// Uncomment on a post
async function uncommentOnPost(req, res) {
  const postId = req.params.id;
  const commentId = req.params.commentId;
  const userId = req.user.id;

  try {
    await postService.uncommentOnPost(postId, userId, commentId);
    res.redirect(`/posts/${postId}`);
  } catch (err) {
    res.render("posts", { error: err.message });
  }
}

module.exports = {
  createPost,
  getPosts,
  getPostById,
  updatePost,
  deletePost,
  likePost,
  commentOnPost,
  uncommentOnPost,
};

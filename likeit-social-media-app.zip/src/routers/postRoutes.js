const express = require('express');
const postRoutes = express.Router();
const postController = require('../controllers/postController');
const checkAuth = require('../middlewares/checkAuthMiddleware');

postRoutes.post('/', checkAuth, postController.createPost);
postRoutes.get('/',  checkAuth, postController.getPosts);
postRoutes.get('/:id',  checkAuth, postController.getPostById);
postRoutes.post('/edit/:id', checkAuth, postController.updatePost);
postRoutes.get('/remove/:id', checkAuth, postController.deletePost);
postRoutes.post('/:id/like',  checkAuth, postController.likePost);
postRoutes.post('/:id/comment',  checkAuth, postController.commentOnPost);
postRoutes.get('/:id/comment/:commentId',  checkAuth, postController.uncommentOnPost);


module.exports = postRoutes;

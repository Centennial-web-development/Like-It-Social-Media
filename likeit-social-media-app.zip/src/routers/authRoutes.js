const express = require('express');
const authRoutes = express.Router();
const authController = require('../controllers/authController');

authRoutes.get('/login', authController.showLogin);
authRoutes.post('/login', authController.login);
authRoutes.get('/register', authController.showRegister);
authRoutes.post('/register', authController.register);
authRoutes.get('/logout', authController.logout);
module.exports = authRoutes;

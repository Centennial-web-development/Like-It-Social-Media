require("./src/config/env");

const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const handlebars = require("express-handlebars");
const session = require("express-session");
const path = require("path");

const connectDb = require("./db");
const authRoutes = require("./src/routers/authRoutes");
const postRoutes = require("./src/routers/postRoutes");
const postService = require("./src/services/postService");

const app = express();
const PORT = process.env.PORT || 4000;
//view engine
app.set("view engine", "ejs");

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
app.use(bodyParser.json());

app.use(cors());

// view  engine
app.set("view engine", "hbs");
app.set("views", path.join(__dirname, "src", "views"));

// hbs engine
app.engine(
  "hbs",
  handlebars.engine({
    extname: "hbs",
    layoutsDir: path.join(path.dirname(__filename), "src", "views", "layouts"),
    defaultLayout: "main",
    helpers: {
      formatDate: (date) => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
      },
      isEqual: function (value1, value2) {
        return value1 === value2;
    }
    },
  })
);

// Use the session middleware
app.use(
  session({
    secret: "likeit",
    resave: true,
    saveUninitialized: true,
    cookie: { maxAge: 3600000 },
  })
);
// this allows to make session global to all views
app.use(function (req, res, next) {
  res.locals.session = req.session;
  next();
});

app.route("/").get(async (req, res, next) => {
  const posts = await postService.getAllPosts();
  console.log("posts", posts);
  return res.render("index", { posts });
});

// Define routes
app.use("/auth", authRoutes);
app.use("/posts", postRoutes);

// 404 route
app.use((req, res, next) => {
  res.status(404).json({
    message: "Route not found",
  });
});

// Error handler
app.use((err, req, res, next) => {
  if (err.name === "UnauthorizedError") {
    res.status(401).json({ message: "Unauthorized" });
  } else {
    console.log(err, "error");
    res.status(500).json({ message: "Internal Server Error" });
  }
});

connectDb().then(() =>
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  })
);

require("./src/config/env");

const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const connectDb = require("./db");
const authRoutes = require("./src/routers/authRoutes");
const postRoutes = require("./src/routers/postRoutes");
const postService = require("./src/services/postService");
const userRoutes = require("./src/routers/userRoutes");

const app = express();
const PORT = process.env.PORT || 4000;

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
app.use(bodyParser.json());

app.use(cors());

app.route("/").get(async (req, res, next) => {
  const posts = await postService.getAllPosts();
  return res.json({ posts });
});

// Define routes
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/posts", postRoutes);

// 404 route
app.use((req, res, next) => {
  res.status(404).json({
    message: "Route not found",
  });
});

// Error handler
app.use((err, req, res, next) => {
  if (err.name === "UnauthorizedError") {
    res.status(401).json({ message: "Unauthorized" });
  } else {
    console.log(err, "error");
    res.status(500).json({ message: "Internal Server Error" });
  }
});

connectDb().then(() =>
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  })
).catch( err => {
  console.error(err);
  process.exit(1);
});

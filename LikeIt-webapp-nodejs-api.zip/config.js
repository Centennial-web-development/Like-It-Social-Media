const path = require("path");
const config = {
  paths: {
    baseDir: path.dirname(__filename),
    viewsPath: path.join(path.dirname(__filename), "src", "views"),
    staticDir: path.join(path.dirname(__filename), "src", "public"),
    uploadDir: path.join(path.dirname(__filename), "src", "public", "uploads"),
  },
  env: {
    PORT: process.env.PORT || 4000,
    HOST: process.env.HOST || "localhost",
  },
};
module.exports = config;

const express = require('express');
const postRoutes = express.Router();
const postController = require('../controllers/postController');
const checkAuth = require('../middlewares/checkAuthMiddleware');

postRoutes.get('/', postController.getPosts);
postRoutes.get('/:id', postController.getPostById);
postRoutes.post('/', checkAuth, postController.createPost);
postRoutes.put('/edit/:id', checkAuth, postController.updatePost);
postRoutes.delete('/:id', checkAuth, postController.deletePost);
postRoutes.post('/:id/like',  checkAuth, postController.likePost);
postRoutes.post('/:id/comment',  checkAuth, postController.commentOnPost);
postRoutes.delete('/:id/comment/:commentId',  checkAuth, postController.uncommentOnPost);


module.exports = postRoutes;

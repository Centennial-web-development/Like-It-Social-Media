const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");

const { Schema, model } = mongoose;

const userSchema = new Schema({
  username: { type: String, required: true, unique: true },
  first_name: { type: String, required: true},
  last_name: { type: String, required: true},
  password: { type: String, required: true, select: false },
  bio: String,
  dateJoined: { type: Date, default: Date.now },
  posts: [{ type: Schema.Types.ObjectId, ref: "Post" }],
  comments: [{ type: Schema.Types.ObjectId, ref: "Comment" }],
  likes: [{ type: Schema.Types.ObjectId, ref: "Like" }],
});

// for encrypting password
userSchema.statics.hashPassword = async function (password) {
  return bcrypt.hash(password, 10);
};

// for validating username and password
userSchema.statics.verifyCredentials = async function (username, password) {
  const user = await this.findOne({ username }).select('+password');;

  if (!user) {
    throw new Error("User not found");
  }

  const isPasswordMatch = await bcrypt.compare(password, user.password);
  if (!isPasswordMatch) {
    throw new Error("Invalid password");
  }

  delete user['password'];

  return user;
};

const User = model("User", userSchema);

module.exports = User;

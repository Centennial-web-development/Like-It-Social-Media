const mongoose = require("mongoose");
const { Schema, model } = mongoose;

const commentSchema = new Schema({
  content: { type: String, required: true },
  datePosted: { type: Date, default: Date.now },
  user: { type: Schema.Types.ObjectId, ref: 'User' },
  post: { type: Schema.Types.ObjectId, ref: 'Post' }
});

const Comment = model("Comment", commentSchema);

module.exports = Comment;

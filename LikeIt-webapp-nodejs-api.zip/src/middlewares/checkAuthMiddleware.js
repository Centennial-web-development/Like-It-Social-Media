const jwt = require("jsonwebtoken");
const User = require("../models/userModel");

async function checkAuth(req, res, next) {
  
  const authorizationHeader = req.headers["authorization"];
  const token = authorizationHeader
    ? authorizationHeader.replace("Bearer ", "")
    : null;

    
  try {
    if (!token) {
      return res.status(401).json({ message: "Missing bearer token" });
    }

    // Decode jwt token
    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decodedToken.user.id;

    // Check if user exists
    const user = await User.findById(userId);
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }

    req.user = user;
    next();
  } catch (err) {
    console.log(err);
    return res.status(401).json({ message: "Invalid token" });
  }

}

module.exports = checkAuth;

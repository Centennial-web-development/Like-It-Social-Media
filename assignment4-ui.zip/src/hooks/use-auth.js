import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function useAuth(redirectIfNotLoggedIn = false) {
  const navigate = useNavigate();

  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const token = sessionStorage.getItem("token");

  const user = sessionStorage.getItem("user");
  const userData = user ? JSON.parse(user) : null;

  const checkLoginStatus = useCallback(() => {
    if (token) {
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
    }
  }, [token]);

  const logout = useCallback(() => {
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("user");
    
    setIsLoggedIn(false);
    navigate("/login");
  }, [navigate]);

  useEffect(() => {
    checkLoginStatus();
    if (redirectIfNotLoggedIn && !isLoggedIn && !token) {
      navigate("/login");
    }
  }, [checkLoginStatus, isLoggedIn, navigate, redirectIfNotLoggedIn, token]);

  return { isLoggedIn, token, userData, logout };
}

import React, { useState } from "react";
import { publicApi } from "../api";
import PostCard from "./PostCard";
import UserCard from "./UserCard";

export default function Home() {
  const [posts, setPosts] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  const [followList, setFollowList] = useState([]);

  React.useEffect(() => {
    fetchPosts();
    fetchFollows();
  }, []);

  const fetchPosts = async () => {
    try {
      const response = await publicApi.get("/posts");
      setPosts(response.data.posts);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching posts:", error);
      setLoading(false);
    }
  };
  const fetchFollows = async () => {
    try {
      const response = await publicApi.get("/followers/suggest");
      setFollowList(response.data);
    } catch (error) {
      console.error("Error fetching follower suggestions:", error);
    }
  };

  return (
    <main className="container">
      <div className="text-center">
        <h4>Home</h4>
      </div>
      <div className="main-content-area">
        <div className="row ">
          <div className="col-md-8 col-lg-7">
            {loading ? (
              <div className="text-center">Loading...</div>
            ) : (
              <div>
                {posts.length > 0 ? (
                  posts.map((post) => (
                    <div key={post._id} className="container p-3">
                      <PostCard post={post} onUpdate={fetchPosts} />
                    </div>
                  ))
                ) : (
                  <p className="lead text-center">No posts yet</p>
                )}
              </div>
            )}
          </div>
          <div className="col-md-4 col-lg-5">
            <div className="card">
              <div className="card-header">Users At A glance</div>
              <div className="card-body">
                <div className="container">
                  {followList?.length > 0 ? (
                    <>
                      {followList.map((follow, index) => (
                        <UserCard
                          user={follow.user}
                          key={index}
                          following_you={follow.following_you === 1}
                        />
                      ))}
                    </>
                  ) : null}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

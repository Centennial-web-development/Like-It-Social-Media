import { useNavigate } from "react-router-dom";
import { publicApi } from "../api";
import React from "react";

function Register() {
  const [credentials, setCredentials] = React.useState({
    username: "",
    password: "",
    first_name: "",
    last_name: "",
  });
  const [error, setError] = React.useState("");

  const navigate = useNavigate();

  const handleChange = (e) => {
    setCredentials({
      ...credentials,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await publicApi.post("/auth/register", credentials);
      console.log(response.data, "data ");
      navigate("/posts");
    } catch (error) {
      if (error.response && error.response.status === 400) {
        setError(
          "Invalid credentials. Please check your username and password."
        );
      } else {
        setError("An unexpected error occurred. Please try again later.");
      }
    }
  };
  return (
    <section className="vh-100">
      <div className="mask d-flex align-items-center h-100 gradient-custom-3">
        <div className="container h-100">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col-12 col-md-9 col-lg-7 col-xl-6">
              <div className="card" style={{ borderRadius: "15px" }}>
                <div className="card-body p-5">
                  <h2 className="text-center mb-5">Register on LikeIt</h2>
                  <p>
                    Create your account by entering your email and choosing a
                    password
                  </p>

                  <form onSubmit={handleSubmit}>
                    {error && (
                      <p className="text-danger text-center">{error}</p>
                    )}
                    {/* {{#if error}} */}
                    {/* <span className="text-danger text-center my-1">{{error}}</span> */}
                    {/* {{/if}} */}
                    {/* {{#if message}} */}
                    {/* <span className="text-success text-center my-1">{{message}}</span> */}
                    {/* {{/if}} */}
                    <div className="form-group mb-4">
                      <input
                        type="text"
                        placeholder="First Name"
                        id="first_name"
                        name="first_name"
                        value={credentials.first_name}
                        onChange={handleChange}
                        className="form-control form-control-sm"
                      />
                    </div>
                    <div className="form-group mb-4">
                      <input
                        type="text"
                        placeholder="Last Name"
                        id="last_name"
                        name="last_name"
                        className="form-control form-control-sm"
                        value={credentials.last_name}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="form-group mb-4">
                      <input
                        type="text"
                        placeholder="Username"
                        id="username"
                        name="username"
                        className="form-control form-control-sm"
                        value={credentials.username}
                        onChange={handleChange}
                      />
                    </div>

                    <div className="form-outline mb-4">
                      <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Password"
                        className="form-control form-control-sm"
                        value={credentials.password}
                        onChange={handleChange}
                      />
                      {/* {{#if errors.password}} */}
                      {/* <span className="text-danger float-right">{{errors.password}}</span> */}
                      {/* {{/if}} */}
                    </div>

                    <div className="d-flex justify-content-center">
                      <button
                        type="submit"
                        className="btn btn-primary text-light btn-block btn-lg gradient-custom-4 w-100"
                      >
                        Register
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Register;

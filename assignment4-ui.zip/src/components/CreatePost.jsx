/* eslint-disable react/prop-types */
import React from "react";
import { publicApi } from "../api";
import useAuth from "../hooks/use-auth";

function CreatePost({ onCreated }) {
  useAuth(true);
  
  const [blog, setBlog] = React.useState({ content: "" , image: null});
  const [error, setError] = React.useState("");

  const handleChange = (e) => {

    setBlog({
      ...blog,
      [e.target.name]:  e.target.value,
    });
  };

  const handleFileChange = (e) => {

    setBlog({
      ...blog,
      [e.target.name]: e.target.files[0] 
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(blog)
    try {
      const response = await publicApi.post("/posts", blog,{
        headers:{
          'Content-Type':'multipart/form-data'
        }
      });
      console.log(response.data, "data ");
      if (onCreated) onCreated();
    } catch (error) {
      if (error.response && error.response.status === 400) {
        setError("Error creating post.");
      } else {
        setError("An unexpected error occurred. Please try again later.");
      }
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        {error && <p className="text-danger">{error}</p>}
        <div className="form-group">
          <textarea
            className="form-control form-control-sm"
            name="content"
            id="content"
            rows="3"
            value={blog.content}
            onChange={handleChange}
            placeholder="What's happening?"
            required
          ></textarea>
          <input className="form-control-file" type="file" onChange={handleFileChange} name="image" id="image-home" accept="image/*"></input>
        </div>
        <div className="d-flex justify-content-start align-items-center my-2">
          <button className="btn btn-sm btn-primary rounded-pill" type="submit">
            Create Post
          </button>
        </div>
      </form>
    </div>
  );
}

export default CreatePost;

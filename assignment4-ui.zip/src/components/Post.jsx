import { useCallback, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { publicApi } from "../api";
import useAuth from "../hooks/use-auth";
import formatDate from "../utils/formatDate";

export default function Post() {
  const { id } = useParams();
  const { userData } = useAuth();

  const [post, setPost] = useState(null);
  const fetchPost = useCallback(async () => {
    try {
      const response = await publicApi.get(`/posts/${id}`);
      const postData = response.data;
      console.log(postData, "postData data");
      setPost(postData.post);
      console.log("Post retrieved successfully");
    } catch (error) {
      console.error("Error fetching post:", error);
    }
  }, [id]);

  useEffect(() => {
    fetchPost();
  }, [fetchPost]);

  const [comment, setComment] = useState({
    content: "",
  });

  const [error, setError] = useState("");
  const handleChange = (e) => {
    setComment({
      ...comment,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await publicApi.post(`/posts/${id}/comment`, comment);
      console.log(response.data, "data ");
      fetchPost();
    } catch (error) {
      if (error.response && error.response.status === 400) {
        setError("error occured.");
      } else {
        setError("An unexpected error occurred. Please try again later.");
      }
    }
  };

  const handleLike = async (id) => {
    try {
      await publicApi.post(`/posts/${id}/like`);
      console.log(`Post with ID ${id} liked successfully`);
      fetchPost();
    } catch (error) {
      console.error(`Error liking post with ID ${id}:`, error);
    }
  };

  const handleDelete = async (commentId) => {
    try {
      await publicApi.delete(`/posts/${id}/comment/${commentId}`);
      console.log(`Comment with ID ${commentId} deleted successfully`);
      fetchPost();
    } catch (error) {
      console.error(`Error deleting comment with ID ${commentId}:`, error);
    }
  };
  return (
    <main className="main-content">
      <div className="text-center my-3">
        <h4>Post</h4>
      </div>
      <div className="main-content-area">
        <div className="border-bottom">
          <div className="container p-3">
            <div className="row">
              <div className="col-8">
                <div className="py-1">
                  <h6 className="d-flex justify-content-start align-items-center gap-2">
                    <strong>{post?.user?.full_name}</strong>
                    <span className="text-muted">{post?.user?.username}</span>
                    <span className="small text-muted">{formatDate(post?.datePosted)}</span>
                  </h6>
                  <p className="lead">{post?.content}</p>

                  <span className="fa fa-ellipsis-h"></span>
                  <ul className="list-inline">
                    <li className="list-inline-item">
                      <button
                        type="button"
                        onClick={() => handleLike(post?._id)}
                        className="btn btn-sm btn-outline-success"
                      >
                        Likes {post?.likesCount}
                      </button>
                    </li>
                    <li className="list-inline-item">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-success"
                      >
                        Comments {post?.commentsCount}
                      </button>
                    </li>
                    
                    {post?.user.username === userData?.username ? (
                      <>
                        <li className="list-inline-item">
                          <button
                            type="submit"
                            onClick={() => handleDelete(post?._id)}
                            className="btn btn-sm btn-outline-danger"
                          >
                            Delete Post
                          </button>
                        </li>
                      </>
                    ) : null}
                  </ul>
                </div>
                <hr />
                <h5>Comments</h5>
                {post?.comments?.length ? (
                  <ul className="list-group">
                    {post.comments.map((comment) => (
                      <li key={comment._id} className="list-group-item ">
                        <p>{comment.content}</p>

                        <button
                          onClick={() => handleDelete(comment._id)}
                          type="submit"
                          className="btn btn-sm btn-danger"
                        >
                          Delete
                        </button>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p>No comments yet</p>
                )}
              </div>
              <div className="col-4">
                <form onSubmit={handleSubmit}>
                  {/* Error message display */}
                  {error && <span className="text-danger">{error}</span>}
                  <div className="form-group">
                    <textarea
                      className="form-control form-control-sm"
                      name="content"
                      id="content"
                      rows="3"
                      value={comment.content}
                      placeholder="Your comment"
                      onChange={handleChange}
                      required
                    ></textarea>
                  </div>
                  <div className="d-block py-2">
                    <button
                      className="btn btn-sm btn-primary rounded-pill"
                      type="submit"
                    >
                      Comment
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

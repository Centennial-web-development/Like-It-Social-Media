import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import { Link } from "react-router-dom";
import useAuth from "../hooks/use-auth";

function Header() {
  const { isLoggedIn, logout } = useAuth();

  return (
    <>
      <Navbar bg="dark mb-3" data-bs-theme="dark">
        <Container>
          <Navbar.Brand>
          <Link
              to={"/"}
              className="text-decoration-none text-color-white"
            >
              LikeIt
            </Link>
           
            </Navbar.Brand>
         
          <Nav className="d-flex justify-content-start aline-items-center gap-3 ms-auto">
            <Link
              to={"/posts"}
              className="text-decoration-none text-color-white"
            >
              Posts
            </Link>
            <Link
              to={"/users"}
              className="text-decoration-none text-color-white"
            >
              Users
            </Link>
            {isLoggedIn ? (
              <>
                <Link
                  to={"/profile"}
                  className="text-decoration-none text-color-white"
                >
                  My Profile
                </Link>
                <Link
                  to={"#"}
                  onClick={() => logout()}
                  className="text-decoration-none text-color-white"
                >
                  Logout
                </Link>
              </>
            ) : (
              <>
                <Link
                  to={"/login"}
                  className="text-decoration-none text-color-white"
                >
                  Login
                </Link>
                <Link
                  to={"/register"}
                  className="text-decoration-none text-color-white"
                >
                  Register
                </Link>
              </>
            )}
          </Nav>
        </Container>
      </Navbar>
    </>
  );
}

export default Header;

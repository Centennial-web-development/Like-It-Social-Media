import React from "react";
import formatDate from "../utils/formatDate";

import { Card, Row, Col, Tab, Tabs, ListGroup } from "react-bootstrap";
import PostCard from "./PostCard";

export const UserProfile = ({
  user,
  showDetails = false,
  className,
  onPostUpdate,
}) => {
  return (
    <Card className={`mb-3 ${className ?? ""}`}>
      <Card.Body>
        <Row>
          <Col md={12}>
            <h3 className="title">
              {user.first_name} {user.last_name}{" "}
              <span className="text-muted fw-light">@{user.username}</span>
            </h3>
            <p className="text-muted">Date: {formatDate(user.dateJoined)}</p>
            <p>{user.bio}</p>
            <ul className="list-inline">
              <li className="list-inline-item">
                <strong>{user.posts?.length || 0}</strong> Posts
              </li>
              <li className="list-inline-item">
                <strong>{user.comments?.length || 0}</strong> Comments
              </li>
              <li className="list-inline-item">
                <strong>{user.likes?.length || 0}</strong> Likes
              </li>
            </ul>
          </Col>
        </Row>
      </Card.Body>
      {showDetails ? (
        <Card.Body>
          <Tabs defaultActiveKey="posts">
            <Tab eventKey="posts" title="Posts">
              <ListGroup>
                {user.posts?.map((post) => (
                  <ListGroup.Item key={post._id}>
                    <PostCard
                      post={post}
                      onUpdate={() => (onPostUpdate ? onPostUpdate() : {})}
                    />
                  </ListGroup.Item>
                ))}
              </ListGroup>
            </Tab>
            <Tab eventKey="likes" title="Likes">
              <ListGroup>
                {user.likes?.map((like) => (
                  <ListGroup.Item key={like._id}>
                    {like.post.content}
                  </ListGroup.Item>
                ))}
              </ListGroup>
            </Tab>
            <Tab eventKey="comments" title="Comments">
              <ListGroup>
                {user.comments?.map((comment) => (
                  <ListGroup.Item key={comment._id}>
                    {comment.content}
                  </ListGroup.Item>
                ))}
              </ListGroup>
            </Tab>
          </Tabs>
        </Card.Body>
      ) : null}
    </Card>
  );
};

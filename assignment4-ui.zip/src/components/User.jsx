import { useCallback, useEffect, useState } from "react";

import { publicApi } from "../api";
import { UserProfile } from "./UserProfile";
import { useParams } from "react-router-dom";

const User = () => {
  const [user, setUser] = useState(null);

  const { username } = useParams();

  const getUser = useCallback(async () => {
    try {
      const response = await publicApi.get(`/users/${username}`);
      setUser(response.data);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  }, [username]);

  useEffect(() => {
    getUser();
  }, [getUser]);

  return (
    <div className="container m-auto">
      <h1>User Profile</h1>

      <div className="row">
        <div className="col-sm-12">
          {user && (
            <UserProfile
              user={user}
              className={"h-100"}
              showDetails
              onPostUpdate={getUser}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default User;

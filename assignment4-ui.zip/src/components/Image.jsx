/* eslint-disable react/prop-types */

import { useEffect, useState } from "react";

/* eslint-disable no-undef */
const Image = ({ imageBuffer, className, style }) => {
    const [imageUrl, setImageUrl] = useState('');

    useEffect(() => {
        if (imageBuffer) {
            // Decode the base64 string to binary data
            const binaryData = atob(imageBuffer);
            
            // Convert the binary data to an array buffer
            const arrayBuffer = new ArrayBuffer(binaryData.length);
            const view = new Uint8Array(arrayBuffer);
            for (let i = 0; i < binaryData.length; i++) {
                view[i] = binaryData.charCodeAt(i);
            }

            // Convert the array buffer to a blob
            const blob = new Blob([arrayBuffer], { type: 'image/jpeg' });

            // Create a data URL from the blob
            const url = URL.createObjectURL(blob);
            setImageUrl(url);
        }
    }, [imageBuffer]);

  return <img src={imageUrl} className={className} style={style} alt="Uploaded" />;
};

export default Image;

import { Link } from "react-router-dom";

/* eslint-disable react/prop-types */
const UserCard = ({ user, following_you = false }) => {
  return (
    <div className="media border-bottom px- 1py-2">
      <div className="media-body">
        <div className="d-flex justify-content-between py-1">
          <div>
            <strong className="">
              {" "}
              {user.first_name} {user.last_name}{" "}
            </strong>
            <Link to={`/u/${user.username}`} className="fw-light text-muted">@{user?.username}</Link>
            <p>{user.bio}</p>
            {following_you ? (
              <p className="small text-muted font-italic">Follows you</p>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserCard;

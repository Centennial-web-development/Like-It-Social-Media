import { useCallback, useEffect, useState } from "react";

import { publicApi } from "../api";
import { UserProfile } from "./UserProfile";

const UserList = () => {
  const [users, setUsers] = useState([]);

  const fetchUsers = useCallback(async () => {
    try {
      const response = await publicApi.get("/users");
      console.log(response.data, "users");
      setUsers(response.data);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  }, []);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  return (
    <div className="container m-auto">
      <h1>User List</h1>
      {users.length > 0 ? (
        <div className="row">
          {users.map((user, index) => (
            <div className="col-sm-6 col-md-4 mb-2" key={index}>
              <UserProfile user={user} className={"h-100"}  onPostUpdate={fetchUsers}/>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
};

export default UserList;

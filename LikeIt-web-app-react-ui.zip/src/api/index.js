import axios from "axios";

export const BASE_URL = "http://localhost:4000/api";

const publicApi = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

const axiosApi = axios.create({
  baseURL: BASE_URL,
});

publicApi.interceptors.request.use(
  (config) => {
    const token = sessionStorage.getItem("token");
    console.log("token", token)
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    console.log(config)
    return config;
  },
  (error) => Promise.reject(error)
);

export { axiosApi, publicApi };

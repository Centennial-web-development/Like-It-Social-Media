/* eslint-disable react/prop-types */
import { Link } from "react-router-dom";
import { publicApi } from "../api";
import useAuth from "../hooks/use-auth";
import formatDate from "../utils/formatDate";

export default function PostCard({ post, onUpdate }) {
  const { userData } = useAuth();

  const handleDelete = async (id) => {
    try {
      await publicApi.delete(`/posts/${id}`);
      console.log(`Post with ID ${id} deleted successfully`);
      if (onUpdate) onUpdate();
    } catch (error) {
      console.error(`Error deleting post with ID ${id}:`, error);
    }
  };

  const handleLike = async (id) => {
    try {
      await publicApi.post(`/posts/${id}/like`);
      console.log(`Post with ID ${id} liked successfully`);
      if (onUpdate) onUpdate();
    } catch (error) {
      console.error(`Error liking post with ID ${id}:`, error);
    }
  };
  return (
    <div className="media border-bottom px-3 py-2">
      <div className="media-body">
        <div className=" py-1">
          <h6 className="d-flex justify-content-start align-items-center gap-2">
            <strong>By</strong>
            <span className="text-muted">
              {userData && post?.user.username === userData?.username
                ? "You"
                : post?.user.username}
            </span>
            <span className="small text-muted">
              {formatDate(post?.datePosted)}
            </span>
          </h6>
          <p>{post?.content}</p>
        </div>
        <ul className="list-inline">
          <li className="list-inline-item">
            <button
              type="button"
              onClick={() => handleLike(post?._id)}
              className="btn btn-sm btn-outline-success"
            >
              Likes {post?.likesCount}
            </button>
          </li>
          <li className="list-inline-item">
            <button type="button" className="btn btn-sm btn-outline-success">
              Comments {post?.commentsCount}
            </button>
          </li>
          <li className="list-inline-item">
            <a
              href={`/posts/${post?._id}`}
              className="btn btn-sm btn-outline-primary"
            >
              View Post
            </a>
          </li>
          {post?.user.username === userData?.username ? (
            <>
              <li className="list-inline-item">
                <button
                  type="submit"
                  onClick={() => handleDelete(post?._id)}
                  className="btn btn-sm btn-outline-danger"
                >
                  Delete Post
                </button>
              </li>
              <li className="list-inline-item">
                <Link
                  type="button"
                  className="btn btn-sm btn-outline-primary"
                  to={`/edit-post/${post?._id}`}
                >
                  Edit Post
                </Link>
              </li>
            </>
          ) : null}
        </ul>
      </div>
    </div>
  );
}

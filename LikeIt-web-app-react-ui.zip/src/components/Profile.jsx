import { useCallback, useEffect, useState } from "react";
import useAuth from "../hooks/use-auth";
import { publicApi } from "../api";
import formatDate from "../utils/formatDate";
import PostCard from "./PostCard";

const Profile = () => {
  const { userData: user } = useAuth(true);

  const [userData, setUserData] = useState({
    username: user.username,
    first_name: user.first_name,
    last_name: user.last_name,
    password: user.password,
    bio: user.bio,
  });

  const [profileData, setProfileData] = useState(user);

  const getProfile = useCallback(async () => {
    try {
      const response = await publicApi.get(`/users/profile`);
      const data = response.data;
      console.log(data, "data data");
      setProfileData(data);
      console.log("Post retrieved successfully");
    } catch (error) {
      console.error("Error fetching profile:", error);
    }
  }, []);

  useEffect(() => {
    getProfile();
  }, [getProfile]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await publicApi.post("/users/profile", userData);
      getProfile();
      console.log(response.data, "data ");
    } catch (error) {
      console.log("An unexpected error occurred. Please try again later.");
    }
  };

  return (
    <div className="section">
      <div className="container m-auto">
        <div className="text-center">
          <h4>Profile</h4>
        </div>
        <div className="row">
          <div className="col-md-7">
            <h2>Your Posts</h2>
          {Array.isArray(profileData.posts) && profileData.posts.length > 0 ? (
          profileData.posts.map((post) => (
            <div key={post._id} className="container p-3">
              <PostCard post={post} onUpdate={getProfile} />
            </div>
          ))
        ) : (
          <p className="lead text-center my-5">No posts yet</p>
        )}
          </div>
          <div className="col-md-5">
            <div className="card">
              <div className="card-header">Info</div>
              <div className="card-body">
                <h3 className="title">
                  {profileData.first_name} {profileData.last_name}
                </h3>
                <h5 className="card-subtitle mb-3">@{profileData.username}</h5>
                <p className="text-muted">
                  Date: {formatDate(profileData.dateJoined)}
                </p>
                <hr />
                <p className="lead">{profileData.bio}</p>
              </div>
            </div>
            <div className="card mt-3">
              <div className="card-header">Edit</div>
              <div className="card-body">
                <form onSubmit={handleSubmit}>
                  <div className="mb-3">
                    <label htmlFor="username" className="form-label">
                      Username
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="username"
                      name="username"
                      value={userData.username}
                      disabled
                      readOnly
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="first_name" className="form-label">
                      First Name
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="first_name"
                      name="first_name"
                      value={userData.first_name}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="last_name" className="form-label">
                      Last Name
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="last_name"
                      name="last_name"
                      value={userData.last_name}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="bio" className="form-label">
                      Bio
                    </label>
                    <textarea
                      className="form-control"
                      id="bio"
                      name="bio"
                      value={userData.bio}
                      onChange={handleChange}
                      rows="3"
                    ></textarea>
                  </div>

                  <button type="submit" className="btn btn-primary">
                    Save Changes
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;

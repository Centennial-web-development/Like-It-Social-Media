import { useNavigate } from "react-router-dom";
import { publicApi } from "../api";
import React from "react";

export default function Login() {
  const [credentials, setCredentials] = React.useState({
    username: "",
    password: "",
  });
  const [error, setError] = React.useState("");

  const navigate = useNavigate();

  const handleChange = (e) => {
    setCredentials({
      ...credentials,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await publicApi.post("/auth/login", credentials);
      console.log(response.data);
      const { token, user } = response.data;
      sessionStorage.setItem("token", token);
      sessionStorage.setItem("user", JSON.stringify(user));
      navigate("/posts");
    } catch (error) {
      if (error.response && error.response.status === 400) {
        setError(
          "Invalid credentials. Please check your username and password."
        );
      } else {
        setError("An unexpected error occurred. Please try again later.");
      }
    }
  };

  return (
    <section className="vh-100">
      <div className="mask d-flex align-items-center h-100 gradient-custom-3">
        <div className="container h-100">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col-12 col-md-9 col-lg-7 col-xl-6">
              <div className="card" style={{ borderRadius: "15px" }}>
                <div className="card-body p-5">
                  <h2 className="text-uppercase text-center mb-5">
                    Welcome back
                  </h2>
                  <form onSubmit={handleSubmit}>
                    {error && <p className="text-red-500">{error}</p>}
                    <div className="form-group mb-4">
                      <input
                        type="text"
                        placeholder="username"
                        id="username"
                        name="username"
                        className="form-control form-control-lg"
                        value={credentials.username}
                        onChange={handleChange}
                      />
                    </div>

                    <div className="form-group mb-4">
                      <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Password"
                        value={credentials.password}
                        onChange={handleChange}
                        className="form-control form-control-lg"
                      />
                    </div>
                    <div className="d-flex justify-content-center">
                      <button
                        type="submit"
                        className="btn btn-primary text-light btn-block btn-lg gradient-custom-4 w-100"
                      >
                        Login
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

import React from "react";
import formatDate from "../utils/formatDate";

const UserProfile = ({ user }) => {
  return (
    <div className="container">
      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-header">User Profile</div>
            <div className="card-body">
              <h3 className="title">
                {user.first_name} {user.last_name}
              </h3>
              <h5 className="card-subtitle mb-3">@{user.username}</h5>
              <p className="text-muted">Date: {formatDate(user.dateJoined)}</p>
              <hr />
              <p className="lead">{user.bio}</p>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <h3>Posts</h3>
          <ul className="list-group">
            {user.posts.map((post) => (
              <li key={post._id} className="list-group-item">
                {post.content}
              </li>
            ))}
          </ul>

          <h3>Comments on Posts</h3>
          <ul className="list-group">
            {user.comments.map((comment) => (
              <li key={comment._id} className="list-group-item">
                {comment.content}
              </li>
            ))}
          </ul>

          <h3>Liked Posts</h3>
          <ul className="list-group">
            {user.likes.map((like) => (
              <li key={like._id} className="list-group-item">
                {like.post.content}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;

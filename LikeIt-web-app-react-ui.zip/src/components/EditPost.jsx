import useAuth from "../hooks/use-auth";

function EditPost() {
  useAuth(true);
  
  return (
    <div>
      <form action="/posts/{{post._id}}" method="POST">
        <input type="hidden" name="_method" value="PUT" />
        <div className="form-group">
          <label htmlFor="content">Content:</label>
          <textarea
            className="form-control form-control-sm"
            id="content"
            name="content"
            rows="3"
          >
            {/* {{post.content}} */}
          </textarea>
        </div>
        <div className="d-block py-2">
          <button type="submit" className="btn btn-primary">
            Update Post
          </button>
        </div>
      </form>
    </div>
  );
}

export default EditPost;

import { useCallback, useEffect, useState } from "react";

import { publicApi } from "../api";
import formatDate from "../utils/formatDate";

const UserList = () => {
  const [users, setUsers] = useState([]);

  const fetchUsers = useCallback(async () => {
    try {
      const response = await publicApi.get("/users");
      console.log(response.data, "users");
      setUsers(response.data);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  }, []);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  return (
    <div className="container m-auto">
      <h1>User List</h1>
      <table className="table">
        <thead>
          <tr>
            <th>Username</th>
            <th>Date Joined</th>
            <th>Name</th>
            <th>Posts</th>
            <th>Comments</th>
            <th>Likes</th>
          </tr>
        </thead>
        <tbody>
          {users.length > 0 && users.map((user) => (
            <tr key={user.username}>
              <td>{user.username}</td>
              <td>{formatDate(user.dateJoined)}</td>
              <td>
                <h5>
                  {user.first_name} {user.last_name}
                </h5>
                <small className="text-muted">{user.bio}</small>
              </td>
              <td>{user.posts?.length || 0}</td>
              <td>{user.comments?.length || 0}</td>
              <td>{user.likes?.length || 0}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UserList;


export default function Footer() {
  return (
    <div>
      <p className="text-white text-center">© QuizMaster. All rights reserved.</p>
    </div>
  );
}

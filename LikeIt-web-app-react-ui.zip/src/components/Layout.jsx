/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import { Outlet } from "react-router-dom";
function Layout() {
  return (
    <div className="bg-gray-900 w-full">
      <Navbar />
      <Outlet />
      <Footer />
    </div>
  );
}

export default Layout;

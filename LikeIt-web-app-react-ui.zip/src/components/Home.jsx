import React from "react";
import { publicApi } from "../api";
import { Link } from "react-router-dom";
import PostCard from "./PostCard";

export default function Home() {
  const [posts, setPosts] = React.useState([]);
  const [loading, setLoading] = React.useState(true); // Initialize loading state as true

  React.useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const response = await publicApi.get("/posts");
      console.log(response.data, "reponse");
      setPosts(response.data.posts);
      setLoading(false); // Set loading to false after fetching posts
    } catch (error) {
      console.error("Error fetching posts:", error);
      setLoading(false); // Set loading to false even in case of error
    }
  };

  const handleLike = async (id) => {
    try {
      await publicApi.post(`/posts/${id}/like`);
      console.log(`Post with ID ${id} liked successfully`);
    } catch (error) {
      console.error(`Error liking post with ID ${id}:`, error);
    }
  };

  return (
    <main className="container">
      <div className="text-center">
        <h4>Home</h4>
      </div>
      <div className="main-content-area">
        {loading ? (
          <div className="text-center">Loading...</div> // Display loading message or spinner
        ) : (
          <div>
            {posts.length > 0 ? (
              posts.map((post) => (
                <div key={post._id} className="container p-3">
                  <PostCard post={post} />
                </div>
              ))
            ) : (
              <p className="lead text-center">No posts yet</p>
            )}
          </div>
        )}
      </div>
    </main>
  );
}

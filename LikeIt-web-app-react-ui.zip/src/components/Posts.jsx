import { useCallback, useEffect, useState } from "react";
import {  Navigate } from "react-router-dom";
import { publicApi } from "../api";
import CreatePost from "./CreatePost";
import useAuth from "../hooks/use-auth";
import PostCard from "./PostCard";

export default function Posts() {
  const [posts, setPosts] = useState([]);
  const { isLoggedIn, token} = useAuth()

  const fetchPosts = useCallback(async () => {
    try {
      const response = await publicApi.get("/posts");
      console.log(response.data, "posts");
      setPosts(response.data.posts);
    } catch (error) {
      console.error("Error fetching posts:", error);
    }
  }, []);

  useEffect(() => {
    fetchPosts();
  }, [fetchPosts]);


  if (!isLoggedIn && !token) {
    return <Navigate to="/login" />;
  }

  return (
    <main className="main-content">
      <div className="text-center">
        <h4>Posts</h4>
      </div>
      <div className="main-content-area">
        <div className="border-bottom">
          <div className="container p-3">
            <div className="row">
              <div className="col-12">
                <CreatePost onCreated={fetchPosts} />
              </div>
            </div>
          </div>
        </div>
        {Array.isArray(posts) && posts.length > 0 ? (
          posts.map((post) => (
            <div key={post._id} className="container p-3">
              <PostCard post={post} onUpdate={fetchPosts} />
            </div>
          ))
        ) : (
          <p className="lead text-center my-5">No posts yet</p>
        )}
      </div>
    </main>
  );
}
